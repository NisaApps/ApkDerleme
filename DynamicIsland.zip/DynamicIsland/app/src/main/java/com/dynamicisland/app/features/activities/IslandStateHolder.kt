package com.dynamicisland.app.features.activities

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * Tüm etkinliklerin tek kaynağı. Tüm çağrılar ana iş parçacığından yapılmalıdır.
 * Liste önceliğe, eşitse en yeni olana göre sıralanır; ilk eleman kapsülde gösterilir.
 */
object IslandStateHolder {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val timers = mutableMapOf<String, Job>()

    private val _events = MutableStateFlow<List<IslandEvent>>(emptyList())
    val events: StateFlow<List<IslandEvent>> = _events.asStateFlow()

    fun post(event: IslandEvent) {
        _events.update { list ->
            (list.filterNot { it.id == event.id } + event)
                .sortedWith(
                    compareByDescending<IslandEvent> { it.type.priority }
                        .thenByDescending { it.postedAt }
                )
        }
        timers.remove(event.id)?.cancel()
        event.durationMs?.let { ms ->
            timers[event.id] = scope.launch {
                delay(ms)
                remove(event.id)
            }
        }
    }

    fun remove(id: String) {
        timers.remove(id)?.cancel()
        _events.update { list -> list.filterNot { it.id == id } }
    }

    fun clear() {
        timers.values.forEach { it.cancel() }
        timers.clear()
        _events.value = emptyList()
    }
}
