package com.dynamicisland.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.Toast
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.ViewTreeLifecycleOwner
import androidx.lifecycle.ViewTreeViewModelStoreOwner
import androidx.lifecycle.lifecycleScope
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.ViewTreeSavedStateRegistryOwner
import com.dynamicisland.app.R
import com.dynamicisland.app.data.preferences.IslandSettings
import com.dynamicisland.app.data.preferences.SettingsRepository
import com.dynamicisland.app.features.activities.IslandEvent
import com.dynamicisland.app.features.charging.ChargingMonitor
import com.dynamicisland.app.features.music.MusicController
import com.dynamicisland.app.features.music.MusicMonitor
import com.dynamicisland.app.features.activities.IslandStateHolder
import com.dynamicisland.app.ui.MainActivity
import com.dynamicisland.app.ui.island.IslandHost
import com.dynamicisland.app.ui.theme.DynamicIslandTheme
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * Kapsülü TYPE_APPLICATION_OVERLAY penceresi olarak ekranın üstüne çizen ön plan hizmeti.
 * Pencere WRAP_CONTENT olduğundan yalnızca kapsülün kapladığı alan dokunmaları yakalar.
 */
class IslandOverlayService : LifecycleService(), SavedStateRegistryOwner, ViewModelStoreOwner {

    private val savedStateController = SavedStateRegistryController.create(this)
    override val savedStateRegistry: SavedStateRegistry get() = savedStateController.savedStateRegistry
    override val viewModelStore = ViewModelStore()

    private lateinit var windowManager: WindowManager
    private var composeView: ComposeView? = null
    private lateinit var layoutParams: WindowManager.LayoutParams
    private var music: MusicMonitor? = null
    private var charging: ChargingMonitor? = null

    @Volatile
    private var latestSettings = IslandSettings()

    override fun onCreate() {
        savedStateController.performAttach()
        savedStateController.performRestore(null)
        super.onCreate()

        // startForegroundService() çağrısından sonra 5 sn içinde startForeground() zorunludur;
        // bu yüzden izin kontrolünden önce çağrılır.
        startInForeground()

        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, R.string.overlay_permission_missing, Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        addOverlay()
        _isRunning.value = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        return START_STICKY
    }

    override fun onDestroy() {
        _isRunning.value = false
        music?.stop()
        charging?.stop()
        music = null
        charging = null
        composeView?.let { view ->
            view.disposeComposition()
            runCatching { windowManager.removeViewImmediate(view) }
        }
        composeView = null
        IslandStateHolder.clear()
        viewModelStore.clear()
        super.onDestroy()
    }

    private fun addOverlay() {
        val repository = SettingsRepository(applicationContext)
        val density = resources.displayMetrics.density

        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            y = (IslandSettings().offsetYDp * density).toInt()
        }

        val view = ComposeView(this).apply {
            ViewTreeLifecycleOwner.set(this, this@IslandOverlayService)
            ViewTreeViewModelStoreOwner.set(this, this@IslandOverlayService)
            ViewTreeSavedStateRegistryOwner.set(this, this@IslandOverlayService)
            setContent {
                val settings by repository.settings.collectAsState(initial = IslandSettings())
                val events by IslandStateHolder.events.collectAsState()
                DynamicIslandTheme(settings.themeMode) {
                    IslandHost(
                        settings = settings,
                        events = events,
                        onOpenEvent = ::openEvent,
                        onDismissEvent = { IslandStateHolder.remove(it.id) },
                        onOpenSettings = ::openApp,
                        onMusicAction = MusicController::perform,
                    )
                }
            }
        }
        composeView = view
        windowManager.addView(view, layoutParams)

        startMonitors(repository)

        // Konum ayarı değişince pencereyi güncelle.
        lifecycleScope.launch {
            repository.settings.map { it.offsetYDp }.distinctUntilChanged().collect { dp ->
                layoutParams.y = (dp * density).toInt()
                composeView?.let { v -> runCatching { windowManager.updateViewLayout(v, layoutParams) } }
            }
        }
    }

    private fun startMonitors(repository: SettingsRepository) {
        val musicMonitor = MusicMonitor(applicationContext) { latestSettings.showMusic }
        val chargingMonitor = ChargingMonitor(applicationContext) { latestSettings.showCharging }
        music = musicMonitor
        charging = chargingMonitor
        chargingMonitor.start()

        lifecycleScope.launch {
            repository.settings.collect {
                latestSettings = it
                musicMonitor.refresh()
            }
        }
        // Medya oturumlarına yalnızca bildirim dinleyicisi bağlıyken erişilebilir.
        lifecycleScope.launch {
            ListenerStatus.connected.collect { connected ->
                if (connected) musicMonitor.start() else musicMonitor.stop()
            }
        }
    }

    private fun openEvent(event: IslandEvent) {
        try {
            event.contentIntent?.send()
        } catch (_: PendingIntent.CanceledException) {
            // Bildirim kaldırılmış olabilir; sessizce yoksay.
        } catch (_: SecurityException) {
            // Android arka plandan etkinlik açılmasını engellediyse yoksay.
        }
        IslandStateHolder.remove(event.id)
    }

    private fun openApp() {
        startActivity(
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        )
    }

    private fun startInForeground() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID,
                getString(R.string.service_channel_name),
                NotificationManager.IMPORTANCE_LOW,
            )
        )
        val tapIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(getString(R.string.service_notification_title))
            .setContentText(getString(R.string.service_notification_text))
            .setContentIntent(tapIntent)
            .setOngoing(true)
            .setSilent(true)
            .build()
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        } else {
            0
        }
        ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, type)
    }

    companion object {
        private const val CHANNEL_ID = "island_service"
        private const val NOTIFICATION_ID = 1001

        private val _isRunning = MutableStateFlow(false)
        val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

        fun start(context: Context) {
            ContextCompat.startForegroundService(context, Intent(context, IslandOverlayService::class.java))
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, IslandOverlayService::class.java))
        }
    }
}
