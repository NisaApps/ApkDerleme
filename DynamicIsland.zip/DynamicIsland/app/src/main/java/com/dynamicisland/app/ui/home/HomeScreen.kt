package com.dynamicisland.app.ui.home

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.dynamicisland.app.R
import com.dynamicisland.app.data.preferences.AnimationSpeed
import com.dynamicisland.app.data.preferences.IslandSettings
import com.dynamicisland.app.data.preferences.ThemeMode
import com.dynamicisland.app.features.activities.IslandEvent
import com.dynamicisland.app.features.activities.IslandEventType
import com.dynamicisland.app.service.IslandOverlayService
import com.dynamicisland.app.ui.island.IslandHost

@Composable
fun HomeScreen(
    settings: IslandSettings,
    onUpdate: ((IslandSettings) -> IslandSettings) -> Unit,
) {
    val context = LocalContext.current
    var refreshTick by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { refreshTick++ }
    val permissions = remember(refreshTick) { PermissionState.read(context) }
    val running by IslandOverlayService.isRunning.collectAsState()

    val postNotificationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { refreshTick++ }

    LazyColumn(
        modifier = Modifier.safeDrawingPadding(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item {
            Text(
                stringResource(R.string.app_name),
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold,
            )
        }
        item { PreviewCard(settings) }
        item {
            StartStopButton(
                running = running,
                overlayGranted = permissions.overlay,
                onClick = {
                    when {
                        running -> IslandOverlayService.stop(context)
                        !permissions.overlay -> context.openSettings(PermissionState.overlaySettingsIntent(context))
                        else -> IslandOverlayService.start(context)
                    }
                },
            )
        }
        item {
            SectionCard(stringResource(R.string.perm_section)) {
                PermissionRow(
                    title = stringResource(R.string.perm_overlay_title),
                    description = stringResource(R.string.perm_overlay_desc),
                    granted = permissions.overlay,
                    actionLabel = stringResource(R.string.perm_open_settings),
                    onAction = { context.openSettings(PermissionState.overlaySettingsIntent(context)) },
                )
                PermissionRow(
                    title = stringResource(R.string.perm_listener_title),
                    description = stringResource(R.string.perm_listener_desc),
                    granted = permissions.notificationListener,
                    actionLabel = stringResource(R.string.perm_open_settings),
                    onAction = { context.openSettings(PermissionState.listenerSettingsIntent()) },
                )
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    PermissionRow(
                        title = stringResource(R.string.perm_post_title),
                        description = stringResource(R.string.perm_post_desc),
                        granted = permissions.postNotifications,
                        actionLabel = stringResource(R.string.perm_grant),
                        onAction = { postNotificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) },
                    )
                }
            }
        }
        item { IndicatorsCard(settings, onUpdate) }
        item { BehaviorCard(settings, onUpdate) }
        item { CustomizationCard(settings, onUpdate) }
        item {
            SectionCard(stringResource(R.string.roadmap_title)) {
                Text(
                    stringResource(R.string.roadmap_desc),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

private fun Context.openSettings(intent: Intent) {
    try {
        startActivity(intent)
    } catch (_: ActivityNotFoundException) {
        Toast.makeText(this, R.string.perm_settings_unavailable, Toast.LENGTH_LONG).show()
    }
}

@Composable
private fun PreviewCard(settings: IslandSettings) {
    val sender = stringResource(R.string.preview_sender)
    val text = stringResource(R.string.preview_text)
    var previewEvents by remember {
        mutableStateOf(
            listOf(IslandEvent(id = "preview", type = IslandEventType.NOTIFICATION, title = sender, text = text))
        )
    }
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF14141A)),
        shape = RoundedCornerShape(28.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(
                stringResource(R.string.home_preview_title),
                style = MaterialTheme.typography.labelLarge,
                color = Color.White.copy(alpha = 0.6f),
            )
            Spacer(Modifier.height(8.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(170.dp),
                contentAlignment = Alignment.TopCenter,
            ) {
                // Önizleme, gerçek kapsülle aynı bileşeni kullanır.
                IslandHost(
                    settings = settings,
                    events = previewEvents,
                    onOpenEvent = {},
                    onDismissEvent = { previewEvents = emptyList() },
                    onOpenSettings = {},
                )
            }
        }
    }
}

@Composable
private fun StartStopButton(running: Boolean, overlayGranted: Boolean, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(if (running) Color(0xFF2E7D32) else MaterialTheme.colorScheme.outline)
            )
            Spacer(Modifier.size(8.dp))
            Text(
                stringResource(if (running) R.string.island_running else R.string.island_stopped),
                style = MaterialTheme.typography.titleMedium,
            )
        }
        Button(onClick = onClick, modifier = Modifier.fillMaxWidth().height(52.dp)) {
            Text(
                stringResource(
                    when {
                        running -> R.string.island_stop
                        overlayGranted -> R.string.island_start
                        else -> R.string.island_grant_to_start
                    }
                )
            )
        }
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable () -> Unit) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            content()
        }
    }
}

@Composable
private fun PermissionRow(
    title: String,
    description: String,
    granted: Boolean,
    actionLabel: String,
    onAction: () -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
            Text(
                stringResource(if (granted) R.string.perm_granted else R.string.perm_missing),
                style = MaterialTheme.typography.labelLarge,
                color = if (granted) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error,
            )
        }
        Text(
            description,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (!granted) {
            OutlinedButton(onClick = onAction) { Text(actionLabel) }
        }
    }
}

@Composable
private fun SwitchRow(
    title: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit,
    description: String? = null,
) {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (description != null) {
                Text(
                    description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

/** Sürüklerken yerel değer tutar, bırakınca DataStore'a yazar. */
@Composable
private fun SliderRow(
    label: String,
    value: Int,
    range: IntRange,
    format: @Composable (Int) -> String,
    onCommit: (Int) -> Unit,
) {
    var local by remember(value) { mutableFloatStateOf(value.toFloat()) }
    Column {
        Row {
            Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
            Text(format(local.toInt()), style = MaterialTheme.typography.bodyMedium)
        }
        Slider(
            value = local,
            onValueChange = { local = it },
            onValueChangeFinished = { onCommit(local.toInt()) },
            valueRange = range.first.toFloat()..range.last.toFloat(),
        )
    }
}

@Composable
private fun IndicatorsCard(settings: IslandSettings, onUpdate: ((IslandSettings) -> IslandSettings) -> Unit) {
    SectionCard(stringResource(R.string.indicators_title)) {
        SwitchRow(
            stringResource(R.string.show_music),
            settings.showMusic,
            { v -> onUpdate { it.copy(showMusic = v) } },
            stringResource(R.string.show_music_desc),
        )
        SwitchRow(
            stringResource(R.string.show_charging),
            settings.showCharging,
            { v -> onUpdate { it.copy(showCharging = v) } },
            stringResource(R.string.show_charging_desc),
        )
    }
}

@Composable
private fun BehaviorCard(settings: IslandSettings, onUpdate: ((IslandSettings) -> IslandSettings) -> Unit) {
    SectionCard(stringResource(R.string.behavior_title)) {
        SwitchRow(
            stringResource(R.string.notifications_enabled),
            settings.notificationsEnabled,
            { v -> onUpdate { it.copy(notificationsEnabled = v) } },
        )
        SwitchRow(
            stringResource(R.string.auto_expand),
            settings.autoExpand,
            { v -> onUpdate { it.copy(autoExpand = v) } },
        )
        SliderRow(
            stringResource(R.string.notification_duration),
            settings.notificationDurationSec,
            IslandSettings.DURATION_RANGE,
            { stringResource(R.string.format_seconds, it) },
            { v -> onUpdate { it.copy(notificationDurationSec = v) } },
        )
        SwitchRow(
            stringResource(R.string.privacy_mode),
            settings.privacyMode,
            { v -> onUpdate { it.copy(privacyMode = v) } },
            stringResource(R.string.privacy_mode_desc),
        )
        SwitchRow(
            stringResource(R.string.hide_sensitive),
            settings.hideSensitiveContent,
            { v -> onUpdate { it.copy(hideSensitiveContent = v) } },
            stringResource(R.string.hide_sensitive_desc),
        )
    }
}

@Composable
private fun CustomizationCard(settings: IslandSettings, onUpdate: ((IslandSettings) -> IslandSettings) -> Unit) {
    SectionCard(stringResource(R.string.customization_title)) {
        SliderRow(
            stringResource(R.string.custom_width), settings.capsuleWidthDp, IslandSettings.WIDTH_RANGE,
            { stringResource(R.string.format_dp, it) },
        ) { v -> onUpdate { it.copy(capsuleWidthDp = v) } }
        SliderRow(
            stringResource(R.string.custom_height), settings.capsuleHeightDp, IslandSettings.HEIGHT_RANGE,
            { stringResource(R.string.format_dp, it) },
        ) { v -> onUpdate { it.copy(capsuleHeightDp = v) } }
        SliderRow(
            stringResource(R.string.custom_corner), settings.cornerRadiusDp, IslandSettings.CORNER_RANGE,
            { stringResource(R.string.format_dp, it) },
        ) { v -> onUpdate { it.copy(cornerRadiusDp = v) } }
        SliderRow(
            stringResource(R.string.custom_offset), settings.offsetYDp, IslandSettings.OFFSET_RANGE,
            { stringResource(R.string.format_dp, it) },
        ) { v -> onUpdate { it.copy(offsetYDp = v) } }
        SliderRow(
            stringResource(R.string.custom_transparency), settings.transparencyPercent,
            IslandSettings.TRANSPARENCY_RANGE,
            { stringResource(R.string.format_percent, it) },
        ) { v -> onUpdate { it.copy(transparencyPercent = v) } }
        SwitchRow(
            stringResource(R.string.custom_border), settings.borderEnabled,
            { v -> onUpdate { it.copy(borderEnabled = v) } },
        )
        SwitchRow(
            stringResource(R.string.custom_shadow), settings.shadowEnabled,
            { v -> onUpdate { it.copy(shadowEnabled = v) } },
        )

        Text(stringResource(R.string.custom_color), style = MaterialTheme.typography.bodyLarge)
        ColorChoices(settings.colorArgb) { c -> onUpdate { it.copy(colorArgb = c) } }

        Text(stringResource(R.string.custom_animation), style = MaterialTheme.typography.bodyLarge)
        ChipRow {
            AnimationSpeed.entries.forEach { speed ->
                FilterChip(
                    selected = settings.animationSpeed == speed,
                    onClick = { onUpdate { it.copy(animationSpeed = speed) } },
                    label = { Text(stringResource(speed.labelRes())) },
                )
            }
        }

        Text(stringResource(R.string.custom_theme), style = MaterialTheme.typography.bodyLarge)
        ChipRow {
            ThemeMode.entries.forEach { mode ->
                FilterChip(
                    selected = settings.themeMode == mode,
                    onClick = { onUpdate { it.copy(themeMode = mode) } },
                    label = { Text(stringResource(mode.labelRes())) },
                )
            }
        }
    }
}

@Composable
private fun ChipRow(content: @Composable () -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) { content() }
}

private fun AnimationSpeed.labelRes() = when (this) {
    AnimationSpeed.SLOW -> R.string.anim_slow
    AnimationSpeed.NORMAL -> R.string.anim_normal
    AnimationSpeed.FAST -> R.string.anim_fast
    AnimationSpeed.FLUID -> R.string.anim_fluid
    AnimationSpeed.OFF -> R.string.anim_off
}

private fun ThemeMode.labelRes() = when (this) {
    ThemeMode.DARK -> R.string.theme_dark
    ThemeMode.LIGHT -> R.string.theme_light
    ThemeMode.SYSTEM -> R.string.theme_system
}

private data class ColorChoice(val argb: Int, val nameRes: Int)

private val colorChoices = listOf(
    ColorChoice(0xFF000000.toInt(), R.string.color_black),
    ColorChoice(0xFF4A148C.toInt(), R.string.color_purple),
    ColorChoice(0xFF0D47A1.toInt(), R.string.color_blue),
    ColorChoice(0xFFB71C1C.toInt(), R.string.color_red),
    ColorChoice(0xFF1B5E20.toInt(), R.string.color_green),
    ColorChoice(0xFFAD1457.toInt(), R.string.color_pink),
)

@Composable
private fun ColorChoices(selected: Int, onSelect: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        colorChoices.forEach { choice ->
            val name = stringResource(choice.nameRes)
            val isSelected = choice.argb == selected
            Box(
                Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(Color(choice.argb))
                    .border(
                        width = if (isSelected) 3.dp else 1.dp,
                        color = if (isSelected) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.outlineVariant,
                        shape = CircleShape,
                    )
                    .semantics { contentDescription = name }
                    .clickable(role = Role.RadioButton) { onSelect(choice.argb) }
            )
        }
    }
}
