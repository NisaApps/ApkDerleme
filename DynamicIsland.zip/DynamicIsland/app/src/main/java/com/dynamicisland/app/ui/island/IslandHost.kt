package com.dynamicisland.app.ui.island

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.ContentTransform
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dynamicisland.app.R
import com.dynamicisland.app.data.preferences.AnimationSpeed
import com.dynamicisland.app.data.preferences.IslandSettings
import com.dynamicisland.app.features.activities.IslandEvent
import com.dynamicisland.app.features.music.MusicAction
import kotlinx.coroutines.delay

private const val AUTO_EXPAND_MS = 4000L

/** Kapsülün üç temel görünümü + uzun basınca açılan gelişmiş kontrol görünümü. */
enum class IslandMode { SMALL, NORMAL, EXPANDED, CONTROLS }

/**
 * Hem overlay hizmetinde hem de ana ekran önizlemesinde kullanılan kapsül.
 *
 * - Etkinlik yoksa: küçük boş kapsül (dokununca ayarları açar).
 * - Etkinlik gelince: otomatik genişler, kısa süre sonra normal görünüme küçülür.
 * - Dokunma: küçükse genişletir, genişse ilgili uygulamayı açar.
 * - Uzun basma: gelişmiş kontrolleri açar.
 */
@OptIn(ExperimentalFoundationApi::class, ExperimentalAnimationApi::class)
@Composable
fun IslandHost(
    settings: IslandSettings,
    events: List<IslandEvent>,
    onOpenEvent: (IslandEvent) -> Unit,
    onDismissEvent: (IslandEvent) -> Unit,
    onOpenSettings: () -> Unit,
    onMusicAction: (MusicAction) -> Unit = {},
    modifier: Modifier = Modifier,
) {
    val top = events.firstOrNull()
    var expanded by remember { mutableStateOf(false) }
    var controls by remember { mutableStateOf(false) }
    var touched by remember { mutableStateOf(false) }

    LaunchedEffect(top?.id, top?.postedAt) {
        expanded = false
        controls = false
        touched = false
        if (top != null && settings.autoExpand) {
            expanded = true
            delay(AUTO_EXPAND_MS)
            if (!touched && !controls) expanded = false
        }
    }

    val mode = when {
        top == null -> IslandMode.SMALL
        controls -> IslandMode.CONTROLS
        expanded -> IslandMode.EXPANDED
        else -> IslandMode.NORMAL
    }

    val maxWidth = (LocalConfiguration.current.screenWidthDp - 24).coerceAtLeast(200)
    val baseW = settings.capsuleWidthDp
    val baseH = settings.capsuleHeightDp
    val targetW = when (mode) {
        IslandMode.SMALL -> baseW
        IslandMode.NORMAL -> (baseW * 2).coerceAtMost(maxWidth)
        else -> 350.coerceAtMost(maxWidth)
    }
    val targetH = when (mode) {
        IslandMode.SMALL -> baseH
        IslandMode.NORMAL -> baseH + 8
        IslandMode.EXPANDED -> when {
            top?.music != null -> 172
            top?.battery != null -> 120
            else -> 132
        }
        IslandMode.CONTROLS -> 116
    }
    val targetR = when (mode) {
        IslandMode.SMALL, IslandMode.NORMAL -> settings.cornerRadiusDp
        else -> 32
    }

    val speed = settings.animationSpeed
    val animate = speed != AnimationSpeed.OFF
    val w by animateDpAsState(targetW.dp, speed.dpSpec(), label = "islandWidth")
    val h by animateDpAsState(targetH.dp, speed.dpSpec(), label = "islandHeight")
    val r by animateDpAsState(targetR.dp, speed.dpSpec(), label = "islandRadius")

    val height = h.coerceAtLeast(1.dp)
    val shape = RoundedCornerShape(minOf(r, height / 2).coerceAtLeast(0.dp))

    val base = Color(settings.colorArgb)
    val background = base.copy(alpha = 1f - settings.transparencyPercent / 100f)
    val contentColor = if (base.luminance() > 0.5f) Color.Black else Color.White

    val haptics = LocalHapticFeedback.current
    val idleDescription = stringResource(R.string.island_idle_description)
    val description = top?.let { "${it.title}. ${it.text}" } ?: idleDescription

    // Gölgenin kırpılmaması için kapsülün çevresinde boşluk bırakılır.
    Box(modifier.padding(start = 12.dp, end = 12.dp, bottom = 14.dp)) {
        Box(
            Modifier
                .width(w.coerceAtLeast(1.dp))
                .height(height)
                .then(if (settings.shadowEnabled) Modifier.shadow(8.dp, shape) else Modifier)
                .clip(shape)
                .background(background)
                .then(
                    if (settings.borderEnabled) Modifier.border(1.dp, contentColor.copy(alpha = 0.3f), shape)
                    else Modifier
                )
                .semantics(mergeDescendants = true) { contentDescription = description }
                .combinedClickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = {
                        when {
                            top == null -> onOpenSettings()
                            controls -> controls = false
                            !expanded -> {
                                expanded = true
                                touched = true
                            }
                            else -> onOpenEvent(top)
                        }
                    },
                    onLongClick = {
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        if (top != null) {
                            controls = true
                            touched = true
                        } else {
                            onOpenSettings()
                        }
                    },
                )
        ) {
            AnimatedContent(
                targetState = mode to top,
                modifier = Modifier.fillMaxSize(),
                contentKey = { it.first },
                transitionSpec = { islandTransition(speed) },
                label = "islandContent",
            ) { (m, event) ->
                if (event != null) {
                    when (m) {
                        IslandMode.SMALL -> Unit
                        IslandMode.NORMAL -> NormalContent(event, contentColor, animate)
                        IslandMode.EXPANDED -> ExpandedContent(event, contentColor, animate, onMusicAction)
                        IslandMode.CONTROLS -> ControlsContent(
                            contentColor = contentColor,
                            onClose = {
                                controls = false
                                onDismissEvent(event)
                            },
                            onSettings = {
                                controls = false
                                onOpenSettings()
                            },
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalAnimationApi::class)
private fun androidx.compose.animation.AnimatedContentTransitionScope<Pair<IslandMode, IslandEvent?>>
    .islandTransition(speed: AnimationSpeed): ContentTransform {
    val ms = speed.fadeMillis()
    return if (ms == 0) {
        (EnterTransition.None togetherWith ExitTransition.None)
            .using(SizeTransform(clip = false) { _, _ -> snap() })
    } else {
        (fadeIn(tween(ms, delayMillis = ms / 3)) togetherWith fadeOut(tween(ms / 2)))
            .using(SizeTransform(clip = false) { _, _ -> snap() })
    }
}

@Composable
internal fun EventIcon(event: IslandEvent, size: Int, contentColor: Color) {
    val bitmap = event.icon
    Box(
        Modifier
            .size(size.dp)
            .clip(CircleShape)
            .background(contentColor.copy(alpha = 0.12f)),
        contentAlignment = Alignment.Center,
    ) {
        if (bitmap != null) {
            val image = remember(bitmap) { bitmap.asImageBitmap() }
            Image(bitmap = image, contentDescription = null, modifier = Modifier.fillMaxSize())
        } else {
            Icon(
                Icons.Filled.Notifications,
                contentDescription = null,
                tint = contentColor,
                modifier = Modifier.size((size / 2).dp),
            )
        }
    }
}

@Composable
private fun NotificationNormalContent(event: IslandEvent, contentColor: Color) {
    Row(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        EventIcon(event, size = 26, contentColor = contentColor)
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
            Text(
                event.title,
                color = contentColor,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (event.text.isNotBlank()) {
                Text(
                    event.text,
                    color = contentColor.copy(alpha = 0.7f),
                    fontSize = 10.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

@Composable
private fun NotificationExpandedContent(event: IslandEvent, contentColor: Color) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
            EventIcon(event, size = 44, contentColor = contentColor)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    event.title,
                    color = contentColor,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (event.text.isNotBlank()) {
                    Text(
                        event.text,
                        color = contentColor.copy(alpha = 0.85f),
                        fontSize = 13.sp,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
        Text(
            stringResource(R.string.island_tap_hint),
            color = contentColor.copy(alpha = 0.5f),
            fontSize = 11.sp,
            modifier = Modifier.align(Alignment.End),
        )
    }
}

@Composable
private fun ControlsContent(contentColor: Color, onClose: () -> Unit, onSettings: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.Center,
    ) {
        Text(
            stringResource(R.string.island_controls_title),
            color = contentColor,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
        )
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilledTonalButton(onClick = onClose, modifier = Modifier.weight(1f)) {
                Text(stringResource(R.string.island_close))
            }
            FilledTonalButton(onClick = onSettings, modifier = Modifier.weight(1f)) {
                Text(stringResource(R.string.island_settings))
            }
        }
    }
}

@Composable
private fun NormalContent(event: IslandEvent, contentColor: Color, animate: Boolean) = when {
    event.music != null -> MusicNormalContent(event, contentColor, animate)
    event.battery != null -> BatteryNormalContent(event, contentColor)
    else -> NotificationNormalContent(event, contentColor)
}

@Composable
private fun ExpandedContent(
    event: IslandEvent,
    contentColor: Color,
    animate: Boolean,
    onMusicAction: (MusicAction) -> Unit,
) = when {
    event.music != null -> MusicExpandedContent(event, contentColor, animate, onMusicAction)
    event.battery != null -> BatteryExpandedContent(event, contentColor)
    else -> NotificationExpandedContent(event, contentColor)
}
