package com.dynamicisland.app.ui.island

import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.ui.unit.Dp
import com.dynamicisland.app.data.preferences.AnimationSpeed

/** Kapsülün boyut/köşe geçişlerinde kullanılan animasyon. */
fun AnimationSpeed.dpSpec(): AnimationSpec<Dp> = when (this) {
    AnimationSpeed.SLOW -> tween(650, easing = FastOutSlowInEasing)
    AnimationSpeed.NORMAL -> spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMediumLow)
    AnimationSpeed.FAST -> spring(dampingRatio = 0.9f, stiffness = Spring.StiffnessHigh)
    AnimationSpeed.FLUID -> spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessLow)
    AnimationSpeed.OFF -> snap()
}

/** İçerik geçişlerindeki solma süresi (ms). 0 = geçiş animasyonu yok. */
fun AnimationSpeed.fadeMillis(): Int = when (this) {
    AnimationSpeed.SLOW -> 400
    AnimationSpeed.NORMAL -> 220
    AnimationSpeed.FAST -> 120
    AnimationSpeed.FLUID -> 300
    AnimationSpeed.OFF -> 0
}
