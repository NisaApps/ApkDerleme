package com.dynamicisland.app.service

import kotlinx.coroutines.flow.MutableStateFlow

/**
 * Bildirim dinleyicisinin bağlı olup olmadığı. Müzik izleyici, medya oturumlarına yalnızca
 * dinleyici bağlıyken erişebilir; izin sonradan verilirse buradan haberdar olunur.
 */
object ListenerStatus {
    val connected = MutableStateFlow(false)
}
