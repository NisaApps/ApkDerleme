package com.dynamicisland.app.features.music

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import com.dynamicisland.app.features.activities.IslandEvent
import com.dynamicisland.app.features.activities.IslandEventType
import com.dynamicisland.app.features.activities.IslandStateHolder
import com.dynamicisland.app.features.activities.MusicInfo
import com.dynamicisland.app.service.NotificationService

/**
 * Etkin medya oturumlarını (Spotify vb.) izler ve kapsüle müzik etkinliği gönderir.
 * Android, oturum listesini yalnızca bildirim erişimi verilmiş bir dinleyiciye açar;
 * izin yoksa [start] sessizce başarısız olur.
 * Tüm çağrılar ana iş parçacığından yapılmalıdır.
 */
class MusicMonitor(
    private val context: Context,
    private val isEnabled: () -> Boolean,
) {
    private val handler = Handler(Looper.getMainLooper())
    private val manager = context.getSystemService(MediaSessionManager::class.java)
    private val component = ComponentName(context, NotificationService::class.java)

    private var registered = false
    private var controller: MediaController? = null
    private var trackKey: String? = null
    private var trackPostedAt = 0L
    private var artSource: Bitmap? = null
    private var artScaled: Bitmap? = null

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { onSessions(it.orEmpty()) }

    private val callback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) = publish()
        override fun onMetadataChanged(metadata: MediaMetadata?) = publish()
        override fun onSessionDestroyed() = onSessions(activeSessions())
    }

    fun start() {
        stop()
        try {
            manager.addOnActiveSessionsChangedListener(sessionsListener, component, handler)
            registered = true
            onSessions(activeSessions())
        } catch (_: SecurityException) {
            registered = false // Bildirim erişimi verilmemiş.
        }
    }

    fun stop() {
        if (registered) {
            runCatching { manager.removeOnActiveSessionsChangedListener(sessionsListener) }
            registered = false
        }
        controller?.let { runCatching { it.unregisterCallback(callback) } }
        controller = null
        MusicController.controller = null
        trackKey = null
        IslandStateHolder.remove(EVENT_ID)
    }

    /** Ayarlar değişince çağrılır. */
    fun refresh() = publish()

    private fun activeSessions(): List<MediaController> = try {
        manager.getActiveSessions(component)
    } catch (_: SecurityException) {
        emptyList()
    }

    private fun onSessions(list: List<MediaController>) {
        val chosen = list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list.firstOrNull()
        if (chosen?.sessionToken != controller?.sessionToken) {
            controller?.let { runCatching { it.unregisterCallback(callback) } }
            controller = chosen
            chosen?.registerCallback(callback, handler)
            trackKey = null
        }
        MusicController.controller = chosen
        publish()
    }

    private fun publish() {
        val c = controller
        val metadata = c?.metadata
        val state = c?.playbackState
        if (c == null || metadata == null || state == null || !isEnabled()) {
            IslandStateHolder.remove(EVENT_ID)
            return
        }
        val title = metadata.getString(MediaMetadata.METADATA_KEY_TITLE)
        val active = state.state != PlaybackState.STATE_NONE &&
            state.state != PlaybackState.STATE_STOPPED
        if (title.isNullOrBlank() || !active) {
            IslandStateHolder.remove(EVENT_ID)
            return
        }

        val artist = metadata.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: metadata.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST).orEmpty()
        val key = "$title|$artist|${c.packageName}"
        if (key != trackKey) {
            trackKey = key
            trackPostedAt = System.currentTimeMillis()
        }

        val source = metadata.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: metadata.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: metadata.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        if (source !== artSource) {
            artSource = source
            artScaled = source?.let(::scaleDown)
        }

        val playing = state.state == PlaybackState.STATE_PLAYING ||
            state.state == PlaybackState.STATE_BUFFERING
        IslandStateHolder.post(
            IslandEvent(
                id = EVENT_ID,
                type = IslandEventType.MUSIC,
                title = title,
                text = artist,
                icon = artScaled,
                contentIntent = c.sessionActivity,
                // Duraklatılınca bir süre gösterilip kalkar; oynarken kalıcıdır.
                durationMs = if (playing) null else PAUSED_LINGER_MS,
                postedAt = trackPostedAt,
                music = MusicInfo(
                    positionMs = state.position,
                    durationMs = metadata.getLong(MediaMetadata.METADATA_KEY_DURATION),
                    positionUpdateTime = state.lastPositionUpdateTime,
                    speed = state.playbackSpeed,
                    isPlaying = playing,
                ),
            )
        )
    }

    private fun scaleDown(bitmap: Bitmap): Bitmap {
        val max = maxOf(bitmap.width, bitmap.height)
        if (max <= ART_MAX_PX) return bitmap
        val ratio = ART_MAX_PX.toFloat() / max
        return Bitmap.createScaledBitmap(
            bitmap, (bitmap.width * ratio).toInt().coerceAtLeast(1), (bitmap.height * ratio).toInt().coerceAtLeast(1), true
        )
    }

    private companion object {
        const val EVENT_ID = "music"
        const val PAUSED_LINGER_MS = 8_000L
        const val ART_MAX_PX = 256
    }
}
