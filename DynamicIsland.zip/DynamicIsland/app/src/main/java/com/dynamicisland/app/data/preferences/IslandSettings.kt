package com.dynamicisland.app.data.preferences

enum class AnimationSpeed { SLOW, NORMAL, FAST, FLUID, OFF }

enum class ThemeMode { DARK, LIGHT, SYSTEM }

/** Kullanıcının kalıcı olarak sakladığı tüm kapsül ayarları. */
data class IslandSettings(
    // Görünüm
    val capsuleWidthDp: Int = 126,
    val capsuleHeightDp: Int = 36,
    val cornerRadiusDp: Int = 18,
    val offsetYDp: Int = 8,
    /** 0 = tamamen opak, 60 = en şeffaf. */
    val transparencyPercent: Int = 0,
    val borderEnabled: Boolean = false,
    val shadowEnabled: Boolean = true,
    val colorArgb: Int = 0xFF000000.toInt(),
    // Animasyon ve tema
    val animationSpeed: AnimationSpeed = AnimationSpeed.NORMAL,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    // Bildirim davranışı
    val notificationsEnabled: Boolean = true,
    val autoExpand: Boolean = true,
    val notificationDurationSec: Int = 6,
    val privacyMode: Boolean = false,
    val hideSensitiveContent: Boolean = false,
    val blockedPackages: Set<String> = emptySet(),
    // Göstergeler
    val showMusic: Boolean = true,
    val showCharging: Boolean = true,
) {
    companion object {
        val WIDTH_RANGE = 90..200
        val HEIGHT_RANGE = 28..56
        val CORNER_RANGE = 8..28
        val OFFSET_RANGE = 0..48
        val TRANSPARENCY_RANGE = 0..60
        val DURATION_RANGE = 3..15
    }
}
