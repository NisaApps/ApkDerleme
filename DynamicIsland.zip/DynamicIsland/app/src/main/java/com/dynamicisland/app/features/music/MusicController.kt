package com.dynamicisland.app.features.music

import android.media.session.MediaController

enum class MusicAction { PREVIOUS, PLAY_PAUSE, NEXT }

/** Kapsüldeki düğmelerin çalan medya oturumunu kontrol etmesini sağlar. */
object MusicController {

    @Volatile
    var controller: MediaController? = null

    fun perform(action: MusicAction) {
        val c = controller ?: return
        try {
            val controls = c.transportControls
            when (action) {
                MusicAction.PREVIOUS -> controls.skipToPrevious()
                MusicAction.NEXT -> controls.skipToNext()
                MusicAction.PLAY_PAUSE -> {
                    val state = c.playbackState?.state
                    if (state == android.media.session.PlaybackState.STATE_PLAYING ||
                        state == android.media.session.PlaybackState.STATE_BUFFERING
                    ) controls.pause() else controls.play()
                }
            }
        } catch (_: RuntimeException) {
            // Oturum bu sırada kapanmış olabilir; yoksay.
        }
    }
}
