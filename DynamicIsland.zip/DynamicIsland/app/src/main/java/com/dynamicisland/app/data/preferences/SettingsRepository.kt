package com.dynamicisland.app.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.islandDataStore: DataStore<Preferences> by preferencesDataStore(name = "island_settings")

/** DataStore üzerinden ayarları okuyan/yazan depo. Her yerden güvenle oluşturulabilir. */
class SettingsRepository(context: Context) {

    private val store = context.applicationContext.islandDataStore

    val settings: Flow<IslandSettings> = store.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { it.toSettings() }

    suspend fun update(transform: (IslandSettings) -> IslandSettings) {
        store.edit { prefs -> prefs.write(transform(prefs.toSettings())) }
    }

    private object K {
        val width = intPreferencesKey("capsule_width")
        val height = intPreferencesKey("capsule_height")
        val corner = intPreferencesKey("corner_radius")
        val offsetY = intPreferencesKey("offset_y")
        val transparency = intPreferencesKey("transparency")
        val border = booleanPreferencesKey("border")
        val shadow = booleanPreferencesKey("shadow")
        val color = intPreferencesKey("color_argb")
        val anim = stringPreferencesKey("animation_speed")
        val theme = stringPreferencesKey("theme_mode")
        val notifEnabled = booleanPreferencesKey("notifications_enabled")
        val autoExpand = booleanPreferencesKey("auto_expand")
        val duration = intPreferencesKey("notification_duration")
        val privacy = booleanPreferencesKey("privacy_mode")
        val hideSensitive = booleanPreferencesKey("hide_sensitive")
        val blocked = stringSetPreferencesKey("blocked_packages")
        val showMusic = booleanPreferencesKey("show_music")
        val showCharging = booleanPreferencesKey("show_charging")
    }

    private fun Preferences.toSettings(): IslandSettings {
        val d = IslandSettings()
        return IslandSettings(
            capsuleWidthDp = (this[K.width] ?: d.capsuleWidthDp).coerceIn(IslandSettings.WIDTH_RANGE),
            capsuleHeightDp = (this[K.height] ?: d.capsuleHeightDp).coerceIn(IslandSettings.HEIGHT_RANGE),
            cornerRadiusDp = (this[K.corner] ?: d.cornerRadiusDp).coerceIn(IslandSettings.CORNER_RANGE),
            offsetYDp = (this[K.offsetY] ?: d.offsetYDp).coerceIn(IslandSettings.OFFSET_RANGE),
            transparencyPercent = (this[K.transparency] ?: d.transparencyPercent)
                .coerceIn(IslandSettings.TRANSPARENCY_RANGE),
            borderEnabled = this[K.border] ?: d.borderEnabled,
            shadowEnabled = this[K.shadow] ?: d.shadowEnabled,
            colorArgb = this[K.color] ?: d.colorArgb,
            animationSpeed = AnimationSpeed.entries.firstOrNull { it.name == this[K.anim] } ?: d.animationSpeed,
            themeMode = ThemeMode.entries.firstOrNull { it.name == this[K.theme] } ?: d.themeMode,
            notificationsEnabled = this[K.notifEnabled] ?: d.notificationsEnabled,
            autoExpand = this[K.autoExpand] ?: d.autoExpand,
            notificationDurationSec = (this[K.duration] ?: d.notificationDurationSec)
                .coerceIn(IslandSettings.DURATION_RANGE),
            privacyMode = this[K.privacy] ?: d.privacyMode,
            hideSensitiveContent = this[K.hideSensitive] ?: d.hideSensitiveContent,
            blockedPackages = this[K.blocked] ?: d.blockedPackages,
            showMusic = this[K.showMusic] ?: d.showMusic,
            showCharging = this[K.showCharging] ?: d.showCharging,
        )
    }

    private fun androidx.datastore.preferences.core.MutablePreferences.write(s: IslandSettings) {
        this[K.width] = s.capsuleWidthDp
        this[K.height] = s.capsuleHeightDp
        this[K.corner] = s.cornerRadiusDp
        this[K.offsetY] = s.offsetYDp
        this[K.transparency] = s.transparencyPercent
        this[K.border] = s.borderEnabled
        this[K.shadow] = s.shadowEnabled
        this[K.color] = s.colorArgb
        this[K.anim] = s.animationSpeed.name
        this[K.theme] = s.themeMode.name
        this[K.notifEnabled] = s.notificationsEnabled
        this[K.autoExpand] = s.autoExpand
        this[K.duration] = s.notificationDurationSec
        this[K.privacy] = s.privacyMode
        this[K.hideSensitive] = s.hideSensitiveContent
        this[K.blocked] = s.blockedPackages
        this[K.showMusic] = s.showMusic
        this[K.showCharging] = s.showCharging
    }
}
