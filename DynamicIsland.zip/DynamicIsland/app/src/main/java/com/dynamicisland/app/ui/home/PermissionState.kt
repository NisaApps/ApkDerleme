package com.dynamicisland.app.ui.home

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

/** Uygulamanın ihtiyaç duyduğu izinlerin anlık durumu. */
data class PermissionState(
    val overlay: Boolean,
    val notificationListener: Boolean,
    val postNotifications: Boolean,
) {
    companion object {
        fun read(context: Context) = PermissionState(
            overlay = Settings.canDrawOverlays(context),
            notificationListener = NotificationManagerCompat
                .getEnabledListenerPackages(context).contains(context.packageName),
            postNotifications = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED,
        )

        fun overlaySettingsIntent(context: Context): Intent =
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))

        fun listenerSettingsIntent(): Intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
    }
}
