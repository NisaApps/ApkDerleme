package com.dynamicisland.app.ui.island

import android.os.SystemClock
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dynamicisland.app.R
import com.dynamicisland.app.features.activities.BatteryEventKind
import com.dynamicisland.app.features.activities.IslandEvent
import com.dynamicisland.app.features.activities.MusicInfo
import com.dynamicisland.app.features.music.MusicAction
import kotlinx.coroutines.delay
import java.util.Locale

private val ChargeGreen = Color(0xFF30D158)
private val LowRed = Color(0xFFFF453A)

// ───────────────────────── Müzik ─────────────────────────

@Composable
internal fun MusicNormalContent(event: IslandEvent, contentColor: Color, animate: Boolean) {
    Row(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        EventIcon(event, size = 26, contentColor = contentColor)
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
            Text(
                event.title, color = contentColor, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            if (event.text.isNotBlank()) {
                Text(
                    event.text, color = contentColor.copy(alpha = 0.7f), fontSize = 10.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
        }
        Spacer(Modifier.width(6.dp))
        WaveformBars(playing = event.music?.isPlaying == true, animate = animate, color = contentColor)
    }
}

@Composable
internal fun MusicExpandedContent(
    event: IslandEvent,
    contentColor: Color,
    animate: Boolean,
    onAction: (MusicAction) -> Unit,
) {
    val info = event.music ?: return
    var now by remember(info) { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    LaunchedEffect(info) {
        while (info.isPlaying) {
            now = SystemClock.elapsedRealtime()
            delay(500)
        }
    }
    val position = currentPosition(info, now)

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            AlbumArt(event, contentColor)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    event.title, color = contentColor, fontSize = 15.sp, fontWeight = FontWeight.Bold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                Text(
                    event.text, color = contentColor.copy(alpha = 0.7f), fontSize = 13.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
            WaveformBars(playing = info.isPlaying, animate = animate, color = contentColor)
        }

        if (info.durationMs > 0) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(formatTime(position), color = contentColor.copy(alpha = 0.7f), fontSize = 10.sp)
                Spacer(Modifier.width(8.dp))
                ProgressBar(
                    fraction = (position.toFloat() / info.durationMs).coerceIn(0f, 1f),
                    color = contentColor,
                    modifier = Modifier.weight(1f),
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    "-" + formatTime(info.durationMs - position),
                    color = contentColor.copy(alpha = 0.7f), fontSize = 10.sp,
                )
            }
        }

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(28.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            ControlButton(stringResource(R.string.music_previous), { onAction(MusicAction.PREVIOUS) }) {
                SkipIcon(forward = false, color = contentColor)
            }
            ControlButton(
                stringResource(if (info.isPlaying) R.string.music_pause else R.string.music_play),
                { onAction(MusicAction.PLAY_PAUSE) },
            ) { PlayPauseIcon(playing = info.isPlaying, color = contentColor) }
            ControlButton(stringResource(R.string.music_next), { onAction(MusicAction.NEXT) }) {
                SkipIcon(forward = true, color = contentColor)
            }
        }
    }
}

private fun currentPosition(info: MusicInfo, now: Long): Long {
    val base = info.positionMs.coerceAtLeast(0L)
    if (!info.isPlaying) return if (info.durationMs > 0) base.coerceAtMost(info.durationMs) else base
    val elapsed = ((now - info.positionUpdateTime) * info.speed).toLong().coerceAtLeast(0L)
    val total = base + elapsed
    return if (info.durationMs > 0) total.coerceAtMost(info.durationMs) else total
}

private fun formatTime(ms: Long): String {
    val totalSec = (ms / 1000).coerceAtLeast(0)
    return String.format(Locale.US, "%d:%02d", totalSec / 60, totalSec % 60)
}

@Composable
private fun AlbumArt(event: IslandEvent, contentColor: Color) {
    val bitmap = event.icon
    Box(
        Modifier
            .size(56.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(contentColor.copy(alpha = 0.12f)),
        contentAlignment = Alignment.Center,
    ) {
        if (bitmap != null) {
            val image = remember(bitmap) { bitmap.asImageBitmap() }
            Image(bitmap = image, contentDescription = null, modifier = Modifier.fillMaxSize())
        } else {
            Text("♪", color = contentColor, fontSize = 24.sp)
        }
    }
}

@Composable
private fun ProgressBar(fraction: Float, color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier
            .height(4.dp)
            .clip(RoundedCornerShape(2.dp))
            .background(color.copy(alpha = 0.2f))
    ) {
        Box(
            Modifier
                .fillMaxHeight()
                .fillMaxWidth(fraction)
                .background(color)
        )
    }
}

@Composable
private fun ControlButton(description: String, onClick: () -> Unit, icon: @Composable () -> Unit) {
    Box(
        Modifier
            .size(44.dp)
            .clip(CircleShape)
            .semantics { contentDescription = description }
            .clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { icon() }
}

/** Ses dalgası animasyonu. [animate] false ise (animasyonlar kapalı) sabit çubuklar çizilir. */
@Composable
internal fun WaveformBars(playing: Boolean, animate: Boolean, color: Color, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "wave")
    val values = List(4) { i ->
        transition.animateFloat(
            initialValue = 0.2f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(420 + i * 140, easing = LinearEasing), RepeatMode.Reverse),
            label = "bar$i",
        )
    }
    Row(
        modifier.height(18.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        values.forEach { v ->
            val fraction = if (playing && animate) v.value else 0.3f
            Box(
                Modifier
                    .width(3.dp)
                    .fillMaxHeight(fraction)
                    .clip(RoundedCornerShape(2.dp))
                    .background(color)
            )
        }
    }
}

@Composable
private fun PlayPauseIcon(playing: Boolean, color: Color, size: Dp = 30.dp) {
    Canvas(Modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        if (playing) {
            val radius = CornerRadius(2.dp.toPx())
            drawRoundRect(color, Offset(w * 0.22f, h * 0.15f), Size(w * 0.2f, h * 0.7f), radius)
            drawRoundRect(color, Offset(w * 0.58f, h * 0.15f), Size(w * 0.2f, h * 0.7f), radius)
        } else {
            val path = Path().apply {
                moveTo(w * 0.28f, h * 0.15f)
                lineTo(w * 0.28f, h * 0.85f)
                lineTo(w * 0.85f, h * 0.5f)
                close()
            }
            drawPath(path, color)
        }
    }
}

@Composable
private fun SkipIcon(forward: Boolean, color: Color, size: Dp = 26.dp) {
    Canvas(Modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        scale(scaleX = if (forward) 1f else -1f, scaleY = 1f, pivot = center) {
            val path = Path().apply {
                moveTo(w * 0.15f, h * 0.2f)
                lineTo(w * 0.15f, h * 0.8f)
                lineTo(w * 0.72f, h * 0.5f)
                close()
            }
            drawPath(path, color)
            drawRoundRect(color, Offset(w * 0.78f, h * 0.2f), Size(w * 0.1f, h * 0.6f), CornerRadius(1.dp.toPx()))
        }
    }
}

// ───────────────────────── Şarj / pil ─────────────────────────

@Composable
internal fun BatteryNormalContent(event: IslandEvent, contentColor: Color) {
    val info = event.battery ?: return
    Row(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        BatteryGlyph(info.level, contentColor, batteryFillColor(info.level, info.kind, contentColor), Modifier.size(28.dp, 14.dp))
        Spacer(Modifier.width(8.dp))
        Text(
            event.title, Modifier.weight(1f), color = contentColor, fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
        )
        Text("%${info.level}", color = contentColor, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
internal fun BatteryExpandedContent(event: IslandEvent, contentColor: Color) {
    val info = event.battery ?: return
    Row(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 22.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        BatteryGlyph(info.level, contentColor, batteryFillColor(info.level, info.kind, contentColor), Modifier.size(76.dp, 38.dp))
        Spacer(Modifier.width(18.dp))
        Column(Modifier.weight(1f)) {
            Text(
                event.title, color = contentColor, fontSize = 16.sp, fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            Text(event.text, color = contentColor.copy(alpha = 0.7f), fontSize = 13.sp, maxLines = 1)
        }
        Text("%${info.level}", color = contentColor, fontSize = 28.sp, fontWeight = FontWeight.Bold)
    }
}

private fun batteryFillColor(level: Int, kind: BatteryEventKind, fallback: Color): Color = when {
    kind == BatteryEventKind.LOW || level <= 15 -> LowRed
    kind == BatteryEventKind.CONNECTED || kind == BatteryEventKind.FULL -> ChargeGreen
    else -> fallback
}

/** Pil simgesi; seviye ilk gösterildiğinde 0'dan hedefe akıcı şekilde dolar. */
@Composable
internal fun BatteryGlyph(level: Int, outline: Color, fill: Color, modifier: Modifier = Modifier) {
    val progress = remember { Animatable(0f) }
    LaunchedEffect(level) { progress.animateTo(level.coerceIn(0, 100) / 100f, tween(900)) }
    Canvas(modifier) {
        val stroke = 1.5.dp.toPx()
        val nubW = 3.dp.toPx()
        val bodyW = size.width - nubW
        drawRoundRect(
            color = outline.copy(alpha = 0.6f),
            topLeft = Offset(stroke / 2, stroke / 2),
            size = Size(bodyW - stroke, size.height - stroke),
            cornerRadius = CornerRadius(size.height * 0.28f),
            style = Stroke(stroke),
        )
        val pad = stroke + 1.dp.toPx()
        val fillW = ((bodyW - 2 * pad) * progress.value).coerceAtLeast(0f)
        if (fillW > 0f) {
            drawRoundRect(
                color = fill,
                topLeft = Offset(pad, pad),
                size = Size(fillW, size.height - 2 * pad),
                cornerRadius = CornerRadius(size.height * 0.16f),
            )
        }
        drawRoundRect(
            color = outline.copy(alpha = 0.6f),
            topLeft = Offset(bodyW + 1.dp.toPx(), size.height * 0.3f),
            size = Size(nubW - 1.dp.toPx(), size.height * 0.4f),
            cornerRadius = CornerRadius(1.dp.toPx()),
        )
    }
}
