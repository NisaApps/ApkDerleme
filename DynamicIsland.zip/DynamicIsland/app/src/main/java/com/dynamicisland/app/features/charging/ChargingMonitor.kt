package com.dynamicisland.app.features.charging

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.core.content.ContextCompat
import com.dynamicisland.app.R
import com.dynamicisland.app.features.activities.BatteryEventKind
import com.dynamicisland.app.features.activities.BatteryInfo
import com.dynamicisland.app.features.activities.IslandEvent
import com.dynamicisland.app.features.activities.IslandEventType
import com.dynamicisland.app.features.activities.IslandStateHolder

/**
 * Pil yayınını (ACTION_BATTERY_CHANGED) dinler; şarj takıldı/çıkarıldı, şarj tamamlandı ve
 * düşük pil durumlarında kapsüle geçici etkinlik gönderir. Ek izin gerektirmez.
 */
class ChargingMonitor(
    private val context: Context,
    private val isEnabled: () -> Boolean,
) {
    private var receiver: BroadcastReceiver? = null
    private var initialized = false
    private var wasCharging = false
    private var fullNotified = false
    private var lowNotified = false

    fun start() {
        if (receiver != null) return
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context, intent: Intent) = handle(intent)
        }
        receiver = r
        val sticky = ContextCompat.registerReceiver(
            context, r, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED
        )
        sticky?.let(::handle)
    }

    fun stop() {
        receiver?.let { runCatching { context.unregisterReceiver(it) } }
        receiver = null
        initialized = false
        IslandStateHolder.remove(EVENT_ID)
    }

    private fun handle(intent: Intent) {
        val rawLevel = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        if (rawLevel < 0 || scale <= 0) return
        val pct = rawLevel * 100 / scale
        val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
        val charging = plugged != 0
        val wireless = plugged == BatteryManager.BATTERY_PLUGGED_WIRELESS
        val full = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1) == BatteryManager.BATTERY_STATUS_FULL ||
            pct >= 100

        if (!initialized) {
            // İlk (sabit) yayın yalnızca başlangıç durumunu belirler, etkinlik göstermez.
            initialized = true
            wasCharging = charging
            fullNotified = charging && full
            lowNotified = !charging && pct <= LOW_THRESHOLD
            return
        }

        val show = isEnabled()
        when {
            charging && !wasCharging -> {
                lowNotified = false
                fullNotified = false
                if (show) post(BatteryEventKind.CONNECTED, pct, wireless)
            }
            !charging && wasCharging -> {
                fullNotified = false
                if (show) post(BatteryEventKind.DISCONNECTED, pct, false)
            }
            charging && full && !fullNotified -> {
                fullNotified = true
                if (show) post(BatteryEventKind.FULL, pct, wireless)
            }
            !charging && pct <= LOW_THRESHOLD && !lowNotified -> {
                lowNotified = true
                if (show) post(BatteryEventKind.LOW, pct, false)
            }
            show -> refreshLevel(pct)
        }
        if (!charging && pct > LOW_THRESHOLD + 5) lowNotified = false
        wasCharging = charging
    }

    /** Şarj etkinliği ekrandayken yüzdeyi günceller (yeniden genişletmeden). */
    private fun refreshLevel(pct: Int) {
        val existing = IslandStateHolder.events.value.firstOrNull { it.id == EVENT_ID } ?: return
        val info = existing.battery ?: return
        if (info.kind != BatteryEventKind.CONNECTED || info.level == pct) return
        IslandStateHolder.post(
            existing.copy(text = context.getString(R.string.battery_level_format, pct), battery = info.copy(level = pct))
        )
    }

    private fun post(kind: BatteryEventKind, pct: Int, wireless: Boolean) {
        val titleRes = when (kind) {
            BatteryEventKind.CONNECTED ->
                if (wireless) R.string.charging_wireless else R.string.charging_title
            BatteryEventKind.DISCONNECTED -> R.string.charging_unplugged
            BatteryEventKind.FULL -> R.string.charging_full
            BatteryEventKind.LOW -> R.string.battery_low
        }
        val duration = when (kind) {
            BatteryEventKind.CONNECTED -> 4_500L
            BatteryEventKind.DISCONNECTED -> 3_000L
            BatteryEventKind.FULL -> 5_000L
            BatteryEventKind.LOW -> 6_000L
        }
        IslandStateHolder.post(
            IslandEvent(
                id = EVENT_ID,
                type = if (kind == BatteryEventKind.LOW) IslandEventType.BATTERY_LOW else IslandEventType.CHARGING,
                title = context.getString(titleRes),
                text = context.getString(R.string.battery_level_format, pct),
                durationMs = duration,
                battery = BatteryInfo(pct, kind, wireless),
            )
        )
    }

    private companion object {
        const val EVENT_ID = "battery"
        const val LOW_THRESHOLD = 15
    }
}
