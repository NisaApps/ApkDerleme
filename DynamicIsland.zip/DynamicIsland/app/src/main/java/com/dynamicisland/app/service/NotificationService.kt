package com.dynamicisland.app.service

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.graphics.drawable.toBitmap
import com.dynamicisland.app.R
import com.dynamicisland.app.data.preferences.IslandSettings
import com.dynamicisland.app.data.preferences.SettingsRepository
import com.dynamicisland.app.features.activities.IslandEvent
import com.dynamicisland.app.features.activities.IslandEventType
import com.dynamicisland.app.features.activities.IslandStateHolder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Bildirimleri yalnızca cihaz üzerinde işler; hiçbir veri ağa gönderilmez.
 * Kullanıcı Android ayarlarından "Bildirim erişimi"ni elle açmalıdır.
 */
class NotificationService : NotificationListenerService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val repository by lazy { SettingsRepository(applicationContext) }

    override fun onListenerConnected() {
        ListenerStatus.connected.value = true
    }

    override fun onListenerDisconnected() {
        ListenerStatus.connected.value = false
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!IslandOverlayService.isRunning.value) return
        if (!isCandidate(sbn)) return
        scope.launch {
            // Gizlilik ayarları her bildirimde güncel okunur (DataStore bellekte önbellekler).
            val settings = repository.settings.first()
            if (!settings.notificationsEnabled || sbn.packageName in settings.blockedPackages) return@launch
            val event = withContext(Dispatchers.Default) { buildEvent(sbn, settings) } ?: return@launch
            IslandStateHolder.post(event)
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        IslandStateHolder.remove(eventId(sbn))
    }

    override fun onDestroy() {
        ListenerStatus.connected.value = false
        scope.cancel()
        super.onDestroy()
    }

    private fun eventId(sbn: StatusBarNotification) = "notif:${sbn.key}"

    /** Sürekli, ilerleme, medya ve grup özeti bildirimleri kapsülde gösterilmez. */
    private fun isCandidate(sbn: StatusBarNotification): Boolean {
        if (sbn.packageName == packageName) return false
        val n = sbn.notification
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return false
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return false
        return when (n.category) {
            Notification.CATEGORY_TRANSPORT,
            Notification.CATEGORY_PROGRESS,
            Notification.CATEGORY_SERVICE,
            Notification.CATEGORY_SYSTEM -> false
            else -> true
        }
    }

    private fun buildEvent(sbn: StatusBarNotification, s: IslandSettings): IslandEvent? {
        val n = sbn.notification
        val extras = n.extras
        val rawTitle = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val rawText = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty()
        if (rawTitle.isBlank() && rawText.isBlank()) return null

        val appLabel = runCatching {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        }.getOrDefault(sbn.packageName)

        val hide = s.privacyMode || (s.hideSensitiveContent && isSensitive(n, rawTitle, rawText))
        val title = if (hide) appLabel else rawTitle.ifBlank { appLabel }
        val text = if (hide) getString(R.string.notif_hidden_text) else rawText

        return IslandEvent(
            id = eventId(sbn),
            type = IslandEventType.NOTIFICATION,
            title = title,
            text = text,
            icon = loadIcon(sbn, preferLargeIcon = !hide),
            contentIntent = n.contentIntent,
            durationMs = s.notificationDurationSec * 1000L,
        )
    }

    private fun isSensitive(n: Notification, title: String, text: String): Boolean {
        if (n.visibility == Notification.VISIBILITY_SECRET) return true
        val joined = "$title $text".lowercase()
        return SENSITIVE_REGEX.containsMatchIn(joined)
    }

    private fun loadIcon(sbn: StatusBarNotification, preferLargeIcon: Boolean) = runCatching {
        val n = sbn.notification
        val drawable = (if (preferLargeIcon) n.getLargeIcon()?.loadDrawable(this) else null)
            ?: runCatching { packageManager.getApplicationIcon(sbn.packageName) }.getOrNull()
            ?: n.smallIcon?.loadDrawable(this)
        drawable?.toBitmap(ICON_PX, ICON_PX)
    }.getOrNull()

    private companion object {
        const val ICON_PX = 96
        val SENSITIVE_REGEX = Regex(
            "(\\b\\d{4,8}\\b)|doğrulama|dogrulama|şifre|sifre|parola|verification|passcode|otp|\\bcode\\b|\\bkod"
        )
    }
}
