package com.dynamicisland.app.features.activities

import android.app.PendingIntent
import android.graphics.Bitmap

/** Kapsülde gösterilebilen etkinlik türleri. Öncelik değeri büyük olan üstte gösterilir. */
enum class IslandEventType(val priority: Int) {
    MUSIC(30),
    NOTIFICATION(50),
    CHARGING(60),
    BATTERY_LOW(70),
}

/** Çalan müziğin anlık durumu. İlerleme, [positionUpdateTime] (elapsedRealtime) üzerinden ilerletilir. */
data class MusicInfo(
    val positionMs: Long,
    val durationMs: Long,
    val positionUpdateTime: Long,
    val speed: Float,
    val isPlaying: Boolean,
)

enum class BatteryEventKind { CONNECTED, DISCONNECTED, FULL, LOW }

data class BatteryInfo(val level: Int, val kind: BatteryEventKind, val wireless: Boolean = false)

/** Kapsülde gösterilecek tek bir etkinlik. */
data class IslandEvent(
    val id: String,
    val type: IslandEventType,
    val title: String,
    val text: String,
    val icon: Bitmap? = null,
    val contentIntent: PendingIntent? = null,
    /** Bu süre sonunda etkinlik otomatik kalkar. null ise elle kapatılana kadar kalır. */
    val durationMs: Long? = null,
    /**
     * Otomatik genişlemeyi tetikleyen zaman damgası. Aynı etkinliğin güncellemelerinde
     * (ör. müzik duraklatma) sabit tutulursa kapsül tekrar genişlemez.
     */
    val postedAt: Long = System.currentTimeMillis(),
    val music: MusicInfo? = null,
    val battery: BatteryInfo? = null,
)
