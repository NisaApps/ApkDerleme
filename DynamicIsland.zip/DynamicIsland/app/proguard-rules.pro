# Aşama 1: özel kural gerekmiyor. Retrofit/JSON eklendiğinde buraya kurallar eklenecek.
